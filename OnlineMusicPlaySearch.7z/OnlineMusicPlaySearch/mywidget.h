#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>
#include<QPainter>                //实现窗口重绘

#include<QNetworkAccessManager>   //url的上传管理
#include<QNetworkRequest>         //http的url请求管理
#include<QNetworkReply>           //网页回复数据触发信号的类

#include<QEventLoop>              //QEventLoop类提供一种进入和离开事件循环的方法

#include<QJsonDocument>
#include<QJsonArray>              //QJsonArray类用于封装JSON数组
#include<QJsonObject>             //QJsonObject类用于封装json对象

#include<QMediaPlayer>
#include<QMediaPlaylist>
#include<QDebug>

#include<QSqlDatabase>
#include<QSqlQuery>
#include<QSqlError>
#include<QSqlRecord>

#include<QMessageBox>
#include<QTime>
#include<math.h>
#include<QMouseEvent>


static QString kugouSearchApi = "http://mobilecdn.kugou.com/api/v3/search/song?";
static QString kugouDownloadApi = "https://wwwapi.kugou.com/yy/index.php?";


QT_BEGIN_NAMESPACE
namespace Ui { class MyWidget; }
QT_END_NAMESPACE

class MyWidget : public QWidget
{
    Q_OBJECT

public:
    MyWidget(QWidget *parent = nullptr);
    ~MyWidget();

    //处理窗口UI图片
    void paintEvent(QPaintEvent *event);

protected:
    //音乐歌曲的下载和播放
    void downloadPlayer(QString album_id,QString hash);

    //访问http网页
    void httpAccess(QString);

    //音乐的hash和ablum_id值解析，使用json
    void hashJsonAnalysis(QByteArray);

    //搜索的音乐数据信息JSON解析，解析出真正的音乐文件和歌词
    QString musicJsonAnalysis(QByteArray);

    void mouseMoveEvent(QMouseEvent* event);
    void mouseReleaseEvent(QMouseEvent* event);
    void mousePressEvent(QMouseEvent* event);


//槽函数-------------------------------------------------------------------------
private slots:
    void on_pushButton_close_clicked();//关闭窗口

    void on_pushButton_skin_clicked();//更换窗口皮肤

    void on_pushButton_about_clicked();//显示关于

    void on_pushButton_search_clicked();//搜索歌曲

    void on_pushButton_name_clicked();//搜索名称

    void on_Progressslider_valueChanged(int value);//进度调节

    void on_Progressslider_sliderPressed();//进度调节--按下

    void on_Progressslider_sliderReleased();//进度调节--释放

    void on_vopSlider_valueChanged(int value);//音量调节

    void on_vopSlider_sliderPressed();//音量调节--按下

    void on_vopSlider_sliderReleased();//音量调节--释放

    void on_pushButton_Front_clicked();//前一首

    void on_pushButton_Playpause_clicked();//播放|暂停

    void on_pushButton_Next_clicked();//下一首

    void on_pushButton_Loopplay_clicked();//循环

    //更新播放的进度条和显示时间
    void updateDuration(qint64);

    //读取网络数据的槽函数
    void netReply(QNetworkReply*);

    //显示歌词的槽函数
    void lyricTextShow(QString);

    //音乐播放
    void playSearchMusic();//双击播放列表，播放音乐

    void playHistoryMusic();//双击历史播放列表，播放音乐

//-----------------------------------------------------------------------------------

private:
    Ui::MyWidget *ui;

    //网络 播放器 sqlite数据库
    QNetworkAccessManager* manager;
    QNetworkRequest* request;

    QMediaPlayer* player;
    QMediaPlaylist* playerList;

    QSqlDatabase db;
    int num,row;//行和列

    //处理鼠标拖动窗口移动操作
    QPoint m_mousePoint;
    QPoint movePoint;
    bool mousePress;



//信号
signals:
    void finish(QByteArray);
    void lyricShow(QString);

};
#endif // MYWIDGET_H
