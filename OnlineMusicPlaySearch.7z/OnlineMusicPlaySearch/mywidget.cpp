#include "mywidget.h"
#include "ui_mywidget.h"


MyWidget::MyWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MyWidget)
{
    ui->setupUi(this);


    //固定窗口尺寸
    this->setFixedSize(this->geometry().size());

    //去掉标题栏
    this->setWindowFlag(Qt::FramelessWindowHint);


    //1:判断数据库连接是否存在，存在得到连接，如果不存在添加得到连接
    if(QSqlDatabase::contains("sql_default_connection"))
    {
        //根据数据库默认连接名称得到连接
        db=QSqlDatabase::database("sql_default_connection");
    }else
    {
        db=QSqlDatabase::addDatabase("QSQLITE");//添加数据库，得到该数据库的默认连接
        db.setDatabaseName("mp3listdatabase.db");//设置数据文件名称
    }

    //2：打开数据库，打开标识(QSqlQuery类)
    if(!db.open())
    {
        //打开数据库失败
        QMessageBox::critical(0,QObject::tr("Open Data Error."),db.lastError().text());
    }else
    {
        //3:定义Query对象，创建数据表searchList
        QSqlQuery query;

        QString sql="create table if not exists searchList"
                    "(id integer,songName text,singerName text,album_id text,hash text);";
        if(!query.exec(sql))
        {
            QMessageBox::critical(0,QObject::tr("create searchList Error."),db.lastError().text());
        }

        //创建数据表historySong，歌曲历史数据表
        sql="create table if not exists historySong"
            "(id integer primary key autoincrement,songName text,singerName text,album_id text,hash text);";
        if(!query.exec(sql))
        {
            QMessageBox::critical(0,QObject::tr("create historySong Error."),db.lastError().text());
        }

        //查询历史数据表中的播放的歌曲数据
        sql="select *from historySong;";
        if(!query.exec(sql))
        {
            QMessageBox::critical(0,QObject::tr("select historySong Error."),db.lastError().text());
        }

        while(query.next())
        {
            QString songName,singerName;
            QSqlRecord rec=query.record();
            int songName_key=rec.indexOf("songName");
            int singerName_key=rec.indexOf("singerName");
            songName=query.value(songName_key).toString();
            singerName=query.value(singerName_key).toString();

            QString strShow=songName+"--"+singerName;
            QListWidgetItem* item=new QListWidgetItem(strShow);
            ui->listWidget_history->addItem(item);
        }
    }

    //4:播放操作
    player=new QMediaPlayer;
    playerList=new QMediaPlaylist;

    connect(player,SIGNAL(positionChanged(qint64)),this,SLOT(updateDuration(qint64)));
    connect(this,SIGNAL(lyricShow(QString)),this,SLOT(lyricTextShow(QString)));
    connect(ui->listWidget_search,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(playSearchMusic()));
    connect(ui->listWidget_history,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(playHistoryMusic()));
    num=0;
}

static bool i = true;

MyWidget::~MyWidget()
{
    delete ui;
}

void MyWidget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/images/musicplayer_ui.jpg"));
}

void MyWidget::downloadPlayer(QString album_id, QString hash)
{
    QString url = kugouDownloadApi + QString("r=play/getdata"
                                             "&hash=%1&album_id=%2"
                                             "&dfid=1spkkh3QKS9P0iJupz0oTy5G"
                                             "&mid=de94e92794f31e9cd6ff4cb309d2baa2"
                                             "&platid=4").arg(hash).arg(album_id);

    httpAccess(url);

    QByteArray JsonData;
    QEventLoop loop;
    auto d = connect(this, finish, [&](const QByteArray & data){
        JsonData = data;
        loop.exit(1);
    });
    loop.exec();
    disconnect(d);

    // 解析将要播放音乐
    QString music = musicJsonAnalysis(JsonData);

    player->setMedia(QUrl(music));

    // 设置音量
    player->setVolume(100);

    // 设置音量的滑动条
    ui->vopSlider->setValue(100);

    // 播放音乐
    player->play();
}

//访问http网页
void MyWidget::httpAccess(QString url)
{
    //实例化网络请求操作事项
    request=new QNetworkRequest;

    //将url网页地址存入到request请求当中
    request->setUrl(url);

    //实例化网络管理(访问)
    manager=new QNetworkAccessManager;

    //通过get方法，上传具体的请求
    manager->get(*request);

    //当网页回复消息时，触发finished信号，我们才能够读取数据信息
    connect(manager,SIGNAL(finished(QNetworkReply*)),this,SLOT(netReply(QNetworkReply*)));
}

//解析网页回复的数据，将搜索得到的音乐hash和album_id与列表的索引值存放到数据库
void MyWidget::hashJsonAnalysis(QByteArray JsonData)
{
    QJsonDocument document=QJsonDocument::fromJson(JsonData);

    if(document.isObject())
    {
        QJsonObject data=document.object();
        if(data.contains("data"))
        {
            QJsonObject objectInfo=data.value("data").toObject();
            if(objectInfo.contains("info"))
            {
                QJsonArray objectHash=objectInfo.value("info").toArray();

                for(int i=0;i<objectHash.count();i++)
                {
                    QString songName,singerName,album_id,hash;
                    QJsonObject album=objectHash.at(i).toObject();

                    if(album.contains("album_id"))
                    {
                        album_id=album.value("album_id").toString();
                    }
                    if(album.contains("singerName"))
                    {
                        singerName=album.value("singerName").toString();
                    }
                    if(album.contains("songName"))
                    {
                        songName=album.value("songName").toString();
                    }
                    if(album.contains("hash"))
                    {
                        hash=album.value("hash").toString();
                    }

                    QSqlQuery query;
                    QString sql = QString("insert into searchList values(%1,'%2','%3','%4','%5');")
                    .arg(QString::number(i)).arg(songName).arg(singerName).arg(album_id).arg(hash);

                    if(!query.exec(sql))
                    {
                        QMessageBox::critical(0,QObject::tr("insert searchList Error."),db.lastError().text());
                    }
                    //将解析的音乐名称，存入searchListWidget控件列表
                    QString show=songName+"--"+singerName;
                    QListWidgetItem *item=new QListWidgetItem(show);
                    ui->listWidget_search->addItem(item);
                }
            }
        }
    }

    if(document.isArray())
    {
        qDebug()<<"Array";
    }
}

//搜索的音乐数据信息json解析，解析出真正的音乐文件和歌词
QString MyWidget::musicJsonAnalysis(QByteArray JsonData)
{
    QJsonDocument documet=QJsonDocument::fromJson(JsonData);

    if(documet.isObject())
    {
        QJsonObject data=documet.object();

        if(data.contains("data"))
        {
            QJsonObject objectPlayUrl=data.value("data").toObject();

            if(objectPlayUrl.contains("lyrics"))
            {
                emit lyricShow(objectPlayUrl.value("lyrics").toString());
            }

            if(objectPlayUrl.contains("play_url"))
            {
                return objectPlayUrl.value("play_url").toString();
            }

        }
        if(documet.isArray())
        {
            qDebug()<<"Array";
        }
    }
}

void MyWidget::mouseMoveEvent(QMouseEvent *event)
{
    if(mousePress)
    {
        QPoint movepos=event->globalPos();//窗口的初始位置
        move(movepos-movePoint);
    }
}

void MyWidget::mouseReleaseEvent(QMouseEvent *event)
{
    //这是一个Qt宏，它的作用是告诉编译器
    //虽然event参数在函数中没有被使用，但这并不是一个错误。
    //在这个特定的函数实现中，确实没有用到event对象所携带的信息，
    //比如鼠标释放的位置、具体按下的是哪个按键等。
    Q_UNUSED(event)
    mousePress=false;
}

void MyWidget::mousePressEvent(QMouseEvent *event)
{
    if(event->button()==Qt::LeftButton)
    {
        mousePress=true;
    }

    m_mousePoint=event->globalPos()-pos();
}

void MyWidget::on_pushButton_close_clicked()
{
    //关闭窗口
    this->close();
}

void MyWidget::on_pushButton_skin_clicked()
{

}

void MyWidget::on_pushButton_about_clicked()
{

}

//搜索音乐
void MyWidget::on_pushButton_search_clicked()
{
    //将原有的歌曲数据清空
    ui->listWidget_search->clear();

    //先清理数据库中已经存储的hash等数据
    QSqlQuery query;
    QString sql="delete from searchList;";

    if(!query.exec(sql))
    {
        QMessageBox::critical(0,QObject::tr("Delete searchList Error."),db.lastError().text());
    }

    //根据用户输入的mp3音乐名称，发起请求操作
    QString url=kugouSearchApi+QString("format=json&keyword=%1&page=1&pagesize=20&showtype=1").
            arg(ui->lineEdit_search->text());
    httpAccess(url);
    QByteArray JsonData;
    QEventLoop loop;

    auto c=connect(this,finish,[&](const QByteArray &data)
    {
        JsonData=data;
        loop.exit(1);
    });

    loop.exec();
    disconnect(c);

    //解析网页回复的数据，将搜索得到的音乐hash跟album_id与列表的索引值存放到数据库
    hashJsonAnalysis(JsonData);
}

void MyWidget::on_pushButton_name_clicked()
{

}

void MyWidget::on_Progressslider_valueChanged(int value)
{
    QTime time(0,value/6000,qRound((value%6000)/1000.0));
    ui->label_time->setText(time.toString("MM:SS"));

    if(i==false)
    {
        player->setPosition(qint64(value));
    }
}

void MyWidget::on_Progressslider_sliderPressed()
{
    i=false;
}

void MyWidget::on_Progressslider_sliderReleased()
{
    i=true;
}

//音量调节
void MyWidget::on_vopSlider_valueChanged(int value)
{
    player->setVolume(value);
    ui->label_vop->setText(QString::number(value));
}

//按下
void MyWidget::on_vopSlider_sliderPressed()
{

}

void MyWidget::on_vopSlider_sliderReleased()
{

}

void MyWidget::on_pushButton_Front_clicked()
{

}

void MyWidget::on_pushButton_Playpause_clicked()
{

}

void MyWidget::on_pushButton_Next_clicked()
{

}

void MyWidget::on_pushButton_Loopplay_clicked()
{

}

void MyWidget::updateDuration(qint64 value)
{
    ui->Progressslider->setRange(0,player->duration());
    ui->Progressslider->setValue(value);
}

//读取网络数据的槽函数
void MyWidget::netReply(QNetworkReply* reply)
{
    // 获取响应的信息，状态码为200属于正常
    QVariant status_code = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    qDebug() << status_code;

    reply->attribute(QNetworkRequest::RedirectionTargetAttribute);


    // 没有错误返回
    if (reply->error() == QNetworkReply::NoError)
    {
        QByteArray data = reply->readAll();
        emit finish(data);
    }
    else
    {
        qDebug()<< reply->errorString();
    }

    reply->deleteLater();
}

void MyWidget::lyricTextShow(QString lyrics)
{
    ui->listWidget_lyric->setFont(QFont("宋体",10,QFont::Bold));
    ui->listWidget_lyric->setTextColor(Qt::white);
    ui->listWidget_lyric->setText(lyrics);
}

//双击搜索播放列表，播放音乐
void MyWidget::playSearchMusic()
{
    //获取双击的歌曲对应索引
    int row=ui->listWidget_search->currentRow();
    qDebug()<<row;

    //查询搜索数据库表中存储的音乐信息
    QSqlQuery query;
    QString sql=QString("select * from searchList where id=%1;").arg(row);

    if(!query.exec(sql))
    {
        QMessageBox::critical(0,QObject::tr("select searchList table Error"),db.lastError().text());
    }

    //将选中的音乐信息存到历史记录表
    QString songName,singerName,album_id,hash;
    while(query.next())
    {
        QSqlRecord recd=query.record();
        int songName_key=recd.indexOf("songName");
        int singerName_key=recd.indexOf("singerName");
        int album_id_key=recd.indexOf("album_id");
        int hash_key=recd.indexOf("hash");

        songName=query.value(songName_key).toString();
        singerName=query.value(singerName_key).toString();
        album_id=query.value(album_id_key).toString();
        hash=query.value(hash_key).toString();

        sql=QString("select hash from historySong where hash='%1';")
                .arg(hash);

        if(!query.exec(sql))
        {
            QMessageBox::critical(0,QObject::tr("select hash Error"),db.lastError().text());
        }

        if(query.next()==NULL)
        {
            sql=QString("insert into historySong values(NULL,'%1','%2','%3','%4');")
                    .arg(songName).arg(singerName).arg(album_id).arg(hash);

            if(!query.exec(sql))
            {
                QMessageBox::critical(0,QObject::tr("insert historySong Error"),db.lastError().text());
            }

            //将解析的音乐名称，保存到历史列表里面
            QString show=songName+"--"+singerName;
            QListWidgetItem* item=new QListWidgetItem(show);
            ui->listWidget_history->addItem(item);
        }
    }
    downloadPlayer(album_id,hash);
}

//双击历史播放列表，播放音乐
void MyWidget::playHistoryMusic()
{
    row=ui->listWidget_history->currentRow();

    //qDebug()<<row;
    QSqlQuery query;
    QString sql=QString("select * from historySong where id=%1;").arg(row);
    if(!query.exec(sql))
    {
        QMessageBox::critical(0,QObject::tr("select historySong table Error"),db.lastError().text());
    }

    //将选中的音乐信息存到历史记录表
    QString album_id,hash;
    while(query.next())
    {
        QSqlRecord recd=query.record();
        int album_id_key=recd.indexOf("album_id");
        int hash_key=recd.indexOf("hash");

        album_id=query.value(album_id_key).toString();
        hash=query.value(hash_key).toString();
    }
    downloadPlayer(album_id,hash);
}

